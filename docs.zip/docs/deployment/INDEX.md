# 部署文档索引

本目录包含 TF2025 项目的部署相关文档。

> 注意：权限能力清单已包含在 `backend/src/config/module-permission-capabilities.json`。
> 部署时上传完整 `backend/`，不再需要额外上传项目根目录 `config`。
> 安全要求：`backend/.env`、`backend/.env.production` 等后端环境文件只存放在运行机器上，严禁提交到 Git。详见[环境配置与密钥管理](../security/ENVIRONMENT_SECRETS.md)。
> 当前拓扑：外部前端通过 HTTPS 提供页面，前端 Nginx 的 `/api/` 与 `/uploads/` 直接代理到家庭后端 `v4.cn9527.cn:3000`。Node 仅监听 3000；若前后端同机，upstream 使用 `127.0.0.1:3000`；若外部前端服务器已加入 P2P 网络，可使用 `10.2.3.10:3000`。可选 `nginx-backend.conf` 的 3001 层不属于当前主链路。
> TLS 提示：HSTS/CSP 应由外部 HTTPS 前端实际返回；HSTS 仅在浏览器通过 HTTPS 访问时生效。

## 文档列表

- [云端部署指南](CLOUD_DEPLOYMENT_GUIDE.md) - 完整的云端服务器部署教程
- [上传文件存储与迁移规范](../backend/upload-storage-standard.md) - 上传目录迁移、数据库 URL 与文件同步发布要求

## 快速开始

### 最简部署流程

```bash
# 1. 安装依赖
sudo apt update
sudo apt install -y nodejs npm mysql-server nginx git

# 2. 克隆项目
cd /var/www
git clone <your-repo> tf2025
cd tf2025
npm run install:all

# 3. 配置数据库
mysql -u root -p
# 创建数据库和用户（详见部署指南）

# 4. 配置环境
cd backend
cp .env.example .env.production
nano .env.production  # 编辑配置
# .env.production 仅留在服务器，不要提交到 Git
chmod 600 .env.production

# 5. 检查后端运行时资源并启动
npm install -g pm2
npm run check:runtime-assets
pm2 start ecosystem.production.config.js --env production
pm2 save

# 6. 构建前端
cd ../frontend
npm run build
sudo cp -r dist/* /www/wwwroot/your-domain/

# 7. 配置外部前端 Nginx（其网络必须能访问家庭 DDNS 后端 3000）
cd ..
sudo cp nginx-frontend.conf /etc/nginx/sites-available/tf2025-frontend
sudo ln -s /etc/nginx/sites-available/tf2025-frontend /etc/nginx/sites-enabled/tf2025-frontend
sudo nginx -t && sudo systemctl reload nginx
```

## 部署架构

```
用户 → Nginx → 前端 (Vue 3 静态文件)
            ↓
         后端 (Node.js API)
            ↓
         数据库 (MySQL)
```

## 服务器要求

| 资源 | 最低配置 | 推荐配置 |
|-----|---------|---------|
| CPU | 2 核 | 4 核+ |
| 内存 | 2GB | 4GB+ |
| 存储 | 20GB SSD | 50GB+ SSD |
| 系统 | Ubuntu 20.04+ | Ubuntu 22.04 LTS |

## 相关文档

- [开发指南](../guides/)
- [数据库同步](../sync/)
- [API 标准](../guides/api-standards.md)
