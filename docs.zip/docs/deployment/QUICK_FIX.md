# 环境变量错误快速修复

> `backend/.env` 和 `backend/.env.production` 可能包含数据库密码、JWT_SECRET 等敏感信息，只保存在服务器；不要提交到 Git，也不要输出完整文件内容。详见[环境配置与密钥管理](../security/ENVIRONMENT_SECRETS.md)。

## 错误信息
```
Error: 缺少必需的环境变量: DB_PASSWORD
at /www/wwwroot/api2025.com/backend/src/config/index.js:10:13
```

## 使用服务器本地生产配置重启

确认服务器本地的 `backend/.env.production` 已配置后，通过 PM2 配置启动。不要在命令行参数中输入真实密码或密钥。

```bash
cd /www/wwwroot/api2025.com/backend && \
pm2 stop tf2025-api 2>/dev/null || true && \
pm2 delete tf2025-api 2>/dev/null || true && \
pm2 start ecosystem.production.config.js --env production && \
pm2 save && \
echo "服务已重启" && \
pm2 status
```

## 检查结果

```bash
# 查看日志
pm2 logs tf2025-api

# 查看状态
pm2 status
```

## 如果问题仍然存在

```bash
# 只检查变量是否存在，不输出变量值
ENV_FILE=/www/wwwroot/api2025.com/backend/.env.production
for key in DB_HOST DB_PORT DB_NAME DB_USER DB_PASSWORD JWT_SECRET PORT NODE_ENV; do
  grep -q "^${key}=." "$ENV_FILE" && printf '%s 已设置\n' "$key" || printf '%s 缺失\n' "$key"
done

# 诊断问题
cd /www/wwwroot/api2025.com
bash fix-cloud-env.sh
```

## 常见原因

1. **PM2 没有正确加载 .env 文件** - PM2 不会自动加载 .env 文件，需要明确指定
2. **NODE_ENV 环境变量未设置** - 导致 dotenv 加载了错误的配置文件
3. **.env.production 文件权限问题** - 确保 PM2 进程可以读取该文件

## 永久解决方案

使用 ecosystem 配置文件加载服务器本地的 `.env.production`：

```bash
cd /www/wwwroot/api2025.com/backend
pm2 start ecosystem.production.config.js --env production
pm2 save
```
