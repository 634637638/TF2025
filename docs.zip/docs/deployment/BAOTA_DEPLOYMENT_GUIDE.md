# 宝塔面板部署指南 - 前后端分离跨服务器部署

## 架构说明
- **前端服务器**: 10.2.3.24 (宝塔面板)
- **后端服务器**: v4.cn9527.cn:3000 (Node.js API)
- **说明**: 前端通过 Nginx 反向代理访问 API 时浏览器为同源请求，不需要在前端 Nginx 添加 CORS 响应头。

---

## 步骤一：更新前端 Nginx 配置

在宝塔面板中：

1. 找到网站 `10.2.3.24`
2. 点击「设置」→「配置文件」
3. 替换为以下配置（或手动修改关键部分）

### 关键修改点：

```nginx
# API 代理到后端服务器（关键配置）
location /api/ {
    # 修改这里：指向您的后端服务器
    proxy_pass http://v4.cn9527.cn:3000/api/;

    # HTTP 版本
    proxy_http_version 1.1;

    # 请求头设置
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;

    # 超时设置
    proxy_connect_timeout 120s;
    proxy_send_timeout 120s;
    proxy_read_timeout 120s;

    # 支持文件上传
    client_max_body_size 10M;
}
```

4. 保存配置
5. 重载 Nginx：在宝塔面板「软件商店」→「Nginx」→「重载配置」

---

## 步骤二：更新后端 CORS 配置

在后端服务器 `v4.cn9527.cn` 上：

1. 找到后端项目的 `.env.production` 文件
2. 修改 `ALLOWED_ORIGINS` 配置：

```bash
# 仅填写正式前端的准确 origin（按实际 HTTPS 域名和端口替换）
ALLOWED_ORIGINS=https://your-frontend-domain.example
```

3. 重启后端服务：

```bash
# 使用 PM2 重启
pm2 restart TF2025-backend

# 或使用您项目的重启命令
npm run restart:production
```

---

## 步骤三：验证配置

### 1. 检查前端 Nginx 代理

在前端服务器上执行：

```bash
# 测试 API 代理是否正常
curl -I http://10.2.3.24/api/health

# 应该返回 200 状态码，并包含后端服务器的响应
```

### 2. 检查后端 CORS 配置

```bash
# 同源代理的写请求也需匹配后端 ALLOWED_ORIGINS 中的正式前端 origin
curl -X OPTIONS http://v4.cn9527.cn:3000/api/auth/login \
  -H "Origin: https://your-frontend-domain.example" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Content-Type,Authorization" \
  -v

# 应该返回包含 Access-Control-Allow-Origin 的响应头
```

### 3. 浏览器测试

1. 打开浏览器开发者工具（F12）
2. 访问正式前端 HTTPS 域名
3. 尝试登录
4. 在「Network」标签中检查 `/api/auth/login` 请求

**成功的标志：**
- 请求 URL 使用正式前端 HTTPS 域名下的 `/api/auth/login`（同源相对路径）
- 状态码为：`200 OK`（不是 502）
- 同源代理请求不依赖 `Access-Control-Allow-Origin` 响应头

---

## 常见问题排查

### 问题 1：仍然返回 502 错误

**原因**：Nginx 无法连接到后端服务器

**解决方案**：
1. 检查后端服务器是否正常运行：`curl http://v4.cn9527.cn:3000/health`
2. 确认 OpenP2P/DDNS 路由可达家庭后端 Node 的 3000 端口
3. 检查 Nginx 错误日志：`tail -f /www/wwwlogs/10.2.3.24.error.log`

### 问题 2：CORS 错误

**原因**：后端未允许前端域名

**解决方案**：
1. 确认后端 `.env.production` 中的 `ALLOWED_ORIGINS` 包含前端地址
2. 重启后端服务
3. 检查后端日志中的 CORS 警告信息

### 问题 3：请求 URL 仍然是 50124 端口

**原因**：前端代码中可能有硬编码的 API URL

**解决方案**：
1. 确认前端构建时使用的是 `.env.production` 配置
2. 检查是否有其他文件直接使用了 `http://182.140.180.74:50124`
3. 重新构建前端：`npm run build`

---

## 安全建议

1. **使用 HTTPS**：在生产环境中，建议为前后端都配置 SSL 证书
2. **限制访问来源**：在 `ALLOWED_ORIGINS` 中只添加实际需要的前端域名
3. **配置防火墙**：限制后端 API 只允许特定 IP 访问
4. **启用认证**：确保所有 API 端点都需要身份验证

---

## 完整配置文件

完整的前端 Nginx 配置已保存在：`/Users/imac/Desktop/webtset/TF2025/nginx-baota-frontend.conf`

您可以直接复制到宝塔面板的配置文件中。
