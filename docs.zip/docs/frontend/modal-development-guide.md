# 模态框开发指南

> 本文档保留历史问题背景；当前实施规范以 [`dialog-standards.md`](dialog-standards.md) 为准。

## 问题概述

在国补管理模块开发过程中，遇到了 Element Plus `el-dialog` 组件的白色边框问题，以及相关的样式和时区配置问题。

---

## 问题1：Element Plus Dialog 白色边框问题

### 问题描述
使用 Element Plus 的 `el-dialog` 组件时，对话框周围会出现白色边框/白色背景层，即使设置了 `background: transparent` 也无法完全去除。

### 根本原因
Element Plus 的 `el-dialog` 组件会创建多个嵌套的包装元素：

```
.el-overlay (最外层遮罩)
  └── .el-dialog__wrapper (对话框包装器)
        └── .el-overlay-dialog (遮罩层对话框)
              └── .el-dialog (实际对话框内容)
```

这些包装元素都有默认的白色背景样式，且由于 Element Plus 的样式优先级很高，在 scoped 样式中很难覆盖。

### 解决方案

#### 当前方案：使用 MobileDialog 或统一 el-dialog

新功能统一使用 `MobileDialog`；必须使用原生 `el-dialog` 时复用全局样式：

```vue
<!-- 自定义模态框结构 -->
<template>
  <div v-if="visible" class="modal-overlay" @click.self="close">
    <div class="modal-content">
      <div class="modal-header">
        <h3><i class="fas fa-edit"></i> 标题</h3>
        <button class="btn-close" @click="close">×</button>
      </div>
      <div class="modal-body">
        <!-- 内容 -->
      </div>
      <div class="modal-footer">
        <!-- 底部按钮 -->
      </div>
    </div>
  </div>
</template>

<style lang="scss">
/* 注意：模态框样式不要使用 scoped */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2000;
  display: flex;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(2px);
}

.modal-content {
  background: white;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow: hidden;
}

.modal-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 16px 20px;
  color: white;
  border-radius: 12px 12px 0 0;
}
</style>
```

#### 历史问题的统一修复方式
如果必须使用 `el-dialog`，直接复用全局入口，不要在页面或其他全局文件中新增覆盖：

- 外壳、响应式尺寸、标题、正文和安全区：`frontend/src/styles/components/_dialog.scss`
- 底部操作区：`frontend/src/styles/components/_dialog-actions.scss`
- 按钮语义：`frontend/src/styles/components/_buttons.scss`

新增视觉规则时只修改上述公共文件，并同步更新
`docs/frontend/dialog-standards.md`。

---

## 问题2：Vue scoped 样式无法覆盖模态框样式

### 问题描述
在 Vue 组件中使用 scoped 样式时，自定义模态框的样式无法生效。

### 根本原因
Vue 的 scoped 样式通过添加唯一属性选择器来实现样式隔离。但模态框通过 `v-if` 条件渲染，且通常挂载到 body 根级别，不在组件的 DOM 树内，因此 scoped 样式无法匹配。

### 解决方案
将模态框样式放在**非 scoped** 的 style 块中：

```vue
<style lang="scss" scoped>
// 组件其他 scoped 样式
.component-style {
  color: red;
}
</style>

<style lang="scss">
// 模态框样式 - 不使用 scoped
.modal-overlay {
  position: fixed;
  // ...
}

.modal-content {
  // ...
}
</style>
```

---

## 问题3：日期选择器时区和语言问题

### 问题描述
- Element Plus 日期选择器默认使用 UTC 时区
- 界面显示为英文

### 解决方案

#### 1. 全局配置中文语言包
**文件：`/frontend/src/main.ts`**
```typescript
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

app.use(ElementPlus, {
  locale: zhCn,
})
```

#### 2. 为日期选择器配置时区
```vue
<el-date-picker
  v-model="editForm.apply_time"
  type="datetime"
  placeholder="选择提交时间"
  format="YYYY-MM-DD HH:mm"
  value-format="YYYY-MM-DDTHH:mm"
  :timezone="'Asia/Shanghai'"
  locale="zh-CN"
/>
```

#### 3. 设置当前时间的函数
```typescript
const setCurrentTime = (field: string) => {
  // 获取当前北京时间（UTC+8）
  const now = new Date();
  const beijingTime = new Date(
    now.getTime() + (8 * 60 * 60 * 1000) + (now.getTimezoneOffset() * 60 * 1000)
  );

  const year = beijingTime.getFullYear();
  const month = String(beijingTime.getMonth() + 1).padStart(2, '0');
  const day = String(beijingTime.getDate()).padStart(2, '0');
  const hours = String(beijingTime.getHours()).padStart(2, '0');
  const minutes = String(beijingTime.getMinutes()).padStart(2, '0');

  editForm.value[field] = `${year}-${month}-${day}T${hours}:${minutes}`;
};
```

---

## 最佳实践总结

### ✅ 推荐做法

1. **优先使用统一弹窗组件**
   - 使用项目中的 `MobileDialog` 组件
   - 原生 `el-dialog` 必须复用 `_dialog.scss`
   - 复杂内容只定义业务布局，不复制弹窗外壳

2. **模态框样式放在非 scoped 块**
   - 使用 `<style lang="scss">` 而非 `<style lang="scss" scoped>`
   - 或提取到全局样式文件

3. **统一视觉风格**
   - 头部、遮罩、圆角、阴影和正文背景统一读取 `_dialog.scss` 令牌
   - 不在业务页面复制具体颜色、圆角或间距

4. **全局配置**
   - 在 `main.ts` 中配置 Element Plus 中文语言包
   - 由 `main.ts` 全局加载 `_dialog.scss` 和 `_dialog-actions.scss`

### ❌ 避免做法

1. ❌ 在 scoped 样式中定义模态框样式
2. ❌ 直接使用 el-dialog 而不做样式处理
3. ❌ 忘记配置日期选择器的时区
4. ❌ 使用内联样式覆盖（难维护）

---

## 相关文件

- **统一模态框结构**: `/frontend/src/components/MobileDialog.vue`
- **统一模态框样式**: `/frontend/src/styles/components/_dialog.scss`
- **统一底部按钮**: `/frontend/src/styles/components/_dialog-actions.scss`
- **参考实现**: `/frontend/src/views/salary/SalaryView.vue`
- **本次修复**: `/frontend/src/views/subsidy/SubsidyView.vue`

---

## 快速检查清单

当开发新的模态框时，确保：

- [ ] 使用 MobileDialog 或统一 el-dialog
- [ ] 模态框样式在非 scoped style 块中
- [ ] 头部使用渐变色背景
- [ ] 遮罩层为半透明黑色
- [ ] 关闭按钮有悬停效果
- [ ] 支持点击遮罩关闭
- [ ] 支持 ESC 键关闭
- [ ] 日期选择器配置了时区和语言
- [ ] 关闭时重置表单状态
- [ ] 移动端响应式适配

---

**最后更新**: 2025-01-05
**问题发现**: 国补管理模块开发
**解决方案**: 自定义模态框 + 全局样式修复
