# 业务文档索引

本目录收录已核实的业务规则和业务专题说明。开发规范与部署步骤分别见[开发指南](../guides/INDEX.md)和[部署文档](../deployment/INDEX.md)。

## 考勤与请假

- [考勤计算规则](leave/LEAVE_CALCULATION_RULES.md)
- [考勤日期拆分指南](leave/LEAVE_DATE_SPLIT_GUIDE.md)
- [工资模板考勤天数](leave/LEAVE_DAYS_FROM_SALARY_TEMPLATE.md)
- [待计算考勤处理](leave/LEAVE_PENDING_CALCULATION.md)

## 库存与商品

- [设备序列号与 IMEI 扫码规则](inventory/DEVICE_SCANNING_RULES.md)
- [库存查询测试指南](inventory/inventory-query-testing-guide.md)
- [价格来源同步规则](price-source-sync.md)

## 订单与业务模块

- [新品预定权限与库存联动规则](preorders/PREORDER_PERMISSION_RULES.md)
- [租赁合同业务规则](rentals/RENTAL_CONTRACT_RULES.md)
- [营销公共页面说明](marketing/MARKETING_PUBLIC_PAGE.md)
- [客户管理密码修改功能说明](客户管理密码修改功能.md)

## 销售划拨专题

- [批发代划拨功能总结](批发代划拨功能总结.md)
- [批发划拨功能完成总结](批发划拨功能完成总结.md)
- [批发自动创建销售记录](批发自动创建销售记录.md)
- [销售页面批发划拨集成指南](销售页面批发划拨集成指南.md)

## 其他记录

- [备注字段一致性修改记录](../业务文档/备注字段一致性修改总结.md)

带“总结”“完成”或“记录”的文档描述特定实现批次，不替代当前代码和权限配置；涉及现行操作时应以对应业务页面及后端接口为准。
