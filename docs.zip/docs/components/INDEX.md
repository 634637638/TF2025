# 组件专题索引

本目录保留组件专题说明和早期实现记录，不定义全站强制规范。当前强制前端规范见[前端规范索引](../frontend/INDEX.md)。

## 仍维护的专题

- [模态框使用说明](modal-guide.md)
- [查询详情弹窗说明](query-modals.md)
- [样式使用说明](style-usage-guide.md)
- [AOS 滚动动画接入记录](AOS_SCROLL_ANIMATION.md)

`style-standards.md` 是早期样式约定，仅供历史参考；新代码按前端权威规范及公共样式实现执行。
